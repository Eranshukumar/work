package com.servo.JewelloanService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JewelloanServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JewelloanServiceApplication.class, args);
	}

}
