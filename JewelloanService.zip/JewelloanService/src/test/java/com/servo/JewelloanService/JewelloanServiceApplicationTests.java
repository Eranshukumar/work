package com.servo.JewelloanService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JewelloanServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
